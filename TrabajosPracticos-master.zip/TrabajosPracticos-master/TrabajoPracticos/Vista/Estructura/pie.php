</div>
    </div>
        </div>
            <footer class="text-muted">
                    <div class="container p-3">
                        <p class="float-right mt-auto py-3">
                        <a href="#">Volvamos al inicio</a>
                        </p>
                        <p>Trabajo practico implementando PHP-html y framework como Bootstrap y jQuery</p>
                        <p>Bootstrap: <a href="https://getbootstrap.com/">Visite su sitio.</a></p>
                    </div>
            </footer>
        </div>

            <!-- jQuery and Bootstrap. -->

        <script src='../../JS/jQuery v3.5.1/jquery-3.5.1.slim.min.js'></script>
        <script src='../../JS/Boostrap v.4.5.2/bootstrap.min.js'></script>
        <script src='../../JS/Boostrap v.4.5.2/bootstrapValidator.min.js'></script>
        <!-- Archivo personal de validaciones -->
        <script src='../../JS/Boostrap v.4.5.2/validator.js'></script>
        

    </body>
</html>