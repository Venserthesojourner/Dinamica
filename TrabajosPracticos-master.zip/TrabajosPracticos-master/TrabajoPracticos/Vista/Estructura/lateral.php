<div class="container-fluid">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                    <div class="sidebar-sticky pt-3" style="background-color:#B56357; border-radius: 5px; text-align: center;">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                            <span class="badge badge-secondary" style="margin: 8px;"> Trabajo Practico N° 1</span>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio1/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 1</span>
                                </a>
                                <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio2/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 2</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio3/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 3</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio4/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 4</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio5/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 5</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio6/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 6</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio7/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 7</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico1/Ejercicio8/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 8</span>
                                </a>
                            </li>
                    </ul>
                    <ul class="nav flex-column">
                            <li class="nav-item">
                            <span class="badge badge-secondary" style="margin: 8px;"> Trabajo Practico N° 2</span>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico2/Ejercicio3/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 3</span>
                                </a>
                                <li class="nav-item">
                                <a class="nav-link" href="../../TrabajoPractico2/Ejercicio4/index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                <span style="color: white;">Ejercicio 4</span>
                                </a>
                            </li>
                    </ul>
                </div>
            </nav>
      