<?php

$GLOBALS['ROOT'] =$_SERVER['DOCUMENT_ROOT'] ."/PWD/TrabajoPracticos/";

include_once("../../../../Utiles/funciones.php");

//echo $_SERVER['DOCUMENT_ROOT'];


?>