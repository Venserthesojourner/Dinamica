<?php


$GLOBALS['ROOT'] =$_SERVER['DOCUMENT_ROOT'] ."/UNC/PWD2020/TPBootstrap/";

include_once("utiles/funciones.php");


?>