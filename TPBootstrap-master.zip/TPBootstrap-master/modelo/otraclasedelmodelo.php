<?php


class otraclasedelmodelo
{

}