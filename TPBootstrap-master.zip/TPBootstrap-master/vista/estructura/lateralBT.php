<div
    style="height: 400px; width: 10%; border: 2px solid red; border-radius: 5px; float: left;"
><H1>Este es el lateral</H1></div>
