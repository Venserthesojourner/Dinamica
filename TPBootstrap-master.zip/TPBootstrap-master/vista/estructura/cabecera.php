<html lang="es">
<head>
<title><?php $Titulo?></title>
<header>


</header>
</head>
<body>
<div style="height: 80px; width: 100%; border: 2px solid red; border-radius: 5px;"> <h1>Esta es la cabecera</h1> </div>

<?php

include_once("lateral.php");
?>

