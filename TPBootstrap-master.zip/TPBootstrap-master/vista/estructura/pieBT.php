</main>
</div>
</div>

<footer class="footer mt-auto py-3">
    <div class="container">

        <p>Blog built for <a href="https://getbootstrap.com/">Bootstrap</a> by <a href="https://twitter.com/mdo">Clau</a>.</p>
        <p>
            <a href="#">Back to top</a>
        </p>

    </div>
</footer>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../../TPBootstrap/vista/js/jquery/jquery-3.5.1.slim.min.js"></script>
<script src="../../TPBootstrap/vista/js/popper/popper.min.js"></script>
<script src="../../TPBootstrap/vista/js/bootstrap/4.5.2/bootstrap.min.js"></script>
<script src="../../TPBootstrap/vista/js/bootstrap/4.5.2/bootstrapValidator.min.js"></script>

<script type="text/javascript" src="../../TPBootstrap/vista/js/bootstrap/4.5.2/validator.js"></script>
</body>
</html>
