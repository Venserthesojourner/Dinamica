
<div style="height: 80px; width: 100%; border: 2px solid red; border-radius: 5px;"> <h1>Este es el Pie</h1> </div>
</html>