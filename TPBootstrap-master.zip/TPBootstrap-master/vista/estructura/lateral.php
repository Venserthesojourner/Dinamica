<div
    style="height: 400px; width: 10%; border: 2px solid red; border-radius: 5px; float: left;"
><H1>Este es el lateral</H1>

    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link active" href="../../TPBootstrap/vista/index.php">
                Ejercicio 4
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../../TPBootstrap/vista/indexBT.php">
               Ejercicio  4 con BT
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../../TPBootstrap/vista/indexBT2.php">
                Ejercicio 4 con BT y Grilla
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../../TPBootstrap/vista/indexBT3.php">
                Ejercicio Tigres
            </a>
        </li>
    </ul>


</div>
